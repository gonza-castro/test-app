<template>
    <div class="page-404">
        <img src="../assets/timbo.svg" alt="Logo timbo">
        <h1 class="number-404">404</h1>
        <p class="strong title-404">PÁGINA NO ENCONTRADA</p>
        <br>
        <p>
            No encontramos el torneo que estas buscando! <br>
            Puede que el link sea incorrecto o haya cambiado.
        </p>
        <p class="text-bottom">
            Si sos un administrador de torneo y no ves tu página, puede que aún no hayas <br>publicado tu torneo. Podes hacerlo desde "Mi sitio Timbo" en el admin.
        </p>
    </div>
</template>

<script>
export default {
}
</script>