<template>
  <div>
    <Nuxt />
  </div>
</template>


<script>
	export default {
    
    }
</script>

